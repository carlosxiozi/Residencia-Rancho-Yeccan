@extends('layouts.app')

@section('content')

    <h1>You are currently not connected to any networks.</h1>

@endsection